import express from "express";
import path from "path";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

const upload = multer({ storage: multer.memoryStorage() });

// Lazy initialized Gemini client helper
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is missing.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function generateContentWithRetry(ai: GoogleGenAI, params: any, retries = 3, delayMs = 2000): Promise<any> {
  const modelsToTry = [params.model || "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-1.5-flash"];
  let lastError: any = null;

  for (const model of modelsToTry) {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        const response = await ai.models.generateContent({
          ...params,
          model,
        });
        return response;
      } catch (err: any) {
        lastError = err;
        const isRateLimit = err?.status === 429 || err?.message?.includes("429") || err?.message?.includes("RESOURCE_EXHAUSTED");
        if (isRateLimit && attempt < retries - 1) {
          console.warn(`[Gemini API] Rate limit hit on ${model}, retrying in ${delayMs * (attempt + 1)}ms...`);
          await new Promise((r) => setTimeout(r, delayMs * (attempt + 1)));
        } else {
          // If not rate limit or max retries reached for this model, break and try fallback model
          break;
        }
      }
    }
  }

  throw lastError;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "AI LessonPlan Bilingual Pro" });
});

// Translation API endpoint
app.post("/api/translate", async (req, res) => {
  try {
    const { items, aiMode, alignmentMode, level, subject } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "Missing or invalid 'items' array." });
    }

    const ai = getGeminiClient();

    let temperature = 0.2;
    if (aiMode === "fast") temperature = 0.4;
    if (aiMode === "precise") temperature = 0.1;

    const systemInstruction = `
Bạn là chuyên gia giáo dục Việt Nam, chuyên gia biên soạn giáo án chuẩn Bộ GD&ĐT, và chuyên gia dịch thuật học thuật Anh - Việt.
Nhiệm vụ của bạn là dịch các đoạn văn bản/bảng biểu/công thức từ giáo án tiếng Việt sang tiếng Anh theo CHUẨN THUẬT NGỮ GIÁO DỤC VIỆT NAM (Chương trình GDPT 2018, Công văn 5512, Thông tư Bộ GDĐT, Cambridge, CEFR, UNESCO Education Terms).

QUY TẮC DỊCH THUẬT QUAN TRỌNG:
1. Dịch chính xác, tự nhiên theo đúng ngữ cảnh sư phạm Việt Nam, không dịch máy từng từ.
2. Với thuật ngữ giáo án chuẩn Công văn 5512:
   - Hoạt động: Activity
   - Mục tiêu: Objectives
   - Nội dung: Content
   - Sản phẩm: Expected Products / Products
   - Tổ chức thực hiện: Implementation / Organization & Execution
   - Chuyển giao nhiệm vụ: Task Assignment / Task Transfer
   - Thực hiện nhiệm vụ: Task Execution
   - Báo cáo, thảo luận: Presentation & Discussion / Reporting
   - Kết luận, nhận định: Conclusion & Assessment
   - Mở đầu / Khởi động: Warm-up / Introduction
   - Hình thành kiến thức mới: Knowledge Acquisition / New Knowledge Formation
   - Luyện tập: Practice
   - Vận dụng: Application
   - Phẩm chất: Qualities / Character Attributes
   - Năng lực chung: General Competencies
   - Năng lực đặc thù: Specific Competencies
3. Cấp học context: ${level || "Tất cả các cấp"} | Môn học: ${subject || "Môn học chung"}.
4. Giữ nguyên công thức toán, số liệu, tên riêng, mã hiệu Công văn/Thông tư.
5. Đối với các ĐỀ MỤC / TIÊU ĐỀ (ví dụ: 'I. MỤC TIÊU', '1. Về kiến thức', '2. Về năng lực', 'A. YÊU CẦU'): CHỈ DỊCH nội dung (ví dụ: 'OBJECTIVES', 'Knowledge', 'Competencies') MÀ KHÔNG lặp lại ký hiệu đề mục ('I.', '1.', 'A.'). Tên dịch sẽ được đặt tự động trong ngoặc đơn màu xanh ngay sau tiêu đề gốc.
6. Trả về đúng định dạng JSON chứa mảng các chuỗi dịch tương ứng theo đúng thứ tự mảng đầu vào.
`;

    const prompt = `
Dịch danh sách các câu/đoạn sau từ giáo án tiếng Việt sang tiếng Anh:
${JSON.stringify(items, null, 2)}

Hãy trả về JSON duy nhất có cấu trúc:
{
  "translations": ["chuỗi tiếng Anh 1", "chuỗi tiếng Anh 2", ...]
}
Đảm bảo số lượng phần tử trả về trùng khớp 100% với mảng đầu vào.
`;

    const response = await generateContentWithRetry(ai, {
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature,
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text || "{}";
    const jsonResult = JSON.parse(responseText);

    res.json({ translations: jsonResult.translations || [] });
  } catch (error: any) {
    console.error("Translation API Error:", error);
    res.status(500).json({
      error: error.message || "Failed to process translation with Gemini API.",
    });
  }
});

// Quality Audit API Endpoint
app.post("/api/quality-check", async (req, res) => {
  try {
    const { nodes } = req.body;
    if (!nodes || !Array.isArray(nodes)) {
      return res.status(400).json({ error: "Missing 'nodes' array." });
    }

    const ai = getGeminiClient();

    const sampleNodes = nodes.slice(0, 30).map((n) => ({
      vi: n.contentVi,
      en: n.contentEn,
      type: n.type,
    }));

    const systemInstruction = `
Bạn là Trợ lý Kiểm định Chất lượng Giáo án Song ngữ chuẩn Bộ GD&ĐT.
Hãy phân tích danh sách các đoạn song ngữ Việt - Anh được cung cấp và đánh giá:
1. Độ chính xác thuật ngữ GDPT 2018 (0-100%)
2. Lỗi chính tả / dịch thuật (nếu có)
3. Quy định định dạng: Tiếng Anh in nghiêng, màu xanh #003399, không bold, giữ cỡ chữ.
4. Gợi ý sửa lỗi cụ thể.
`;

    const prompt = `
Phân tích các mẫu song ngữ sau:
${JSON.stringify(sampleNodes, null, 2)}

Trả về JSON có cấu trúc:
{
  "score": 98,
  "summary": "Giáo án đạt chất lượng rất cao, tuân thủ 99% Công văn 5512 và GDPT 2018.",
  "issues": [
    { "type": "terminology|spelling|formatting", "description": "Mô tả lỗi...", "suggestion": "Gợi ý sửa..." }
  ]
}
`;

    const response = await generateContentWithRetry(ai, {
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const jsonResult = JSON.parse(response.text || "{}");
    res.json(jsonResult);
  } catch (error: any) {
    console.error("Quality Audit API Error:", error);
    res.status(500).json({ error: error.message || "Quality check failed." });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
