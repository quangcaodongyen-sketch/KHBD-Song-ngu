import React, { useState, useEffect } from 'react';
import { LessonPlanDocument } from './types';
import { createBlankDocument } from './data/sampleLessonPlans';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { EditorView } from './components/EditorView';

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Initialize main document state with a clean blank document template
  const [currentDoc, setCurrentDoc] = useState<LessonPlanDocument>(createBlankDocument);

  // Sync dark mode class on <html>
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleCreateNewDoc = () => {
    if (
      currentDoc.nodes.length > 0 &&
      !window.confirm('Tạo Kế hoạch bài dạy mới sẽ làm mới trang soạn thảo hiện tại. Bạn có muốn tiếp tục?')
    ) {
      return;
    }
    setCurrentDoc(createBlankDocument());
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-blue-500 selection:text-white">
      {/* Header */}
      <Header
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onNewDocClick={handleCreateNewDoc}
      />

      {/* Main Single View: Editor & Converter */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <EditorView
          currentDoc={currentDoc}
          setCurrentDoc={setCurrentDoc}
          onSaveToLibrary={() => {}}
        />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
