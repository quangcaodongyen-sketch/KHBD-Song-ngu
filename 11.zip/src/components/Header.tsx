import React from 'react';
import { NavTab } from '../types';
import {
  BookOpen,
  FileSpreadsheet,
  History,
  Library,
  Settings,
  HelpCircle,
  PhoneCall,
  Moon,
  Sun,
  Sparkles,
  Award,
} from 'lucide-react';

interface HeaderProps {
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onNewDocClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isDarkMode,
  setIsDarkMode,
  onNewDocClick,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Brand Bar */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center space-x-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg text-slate-900 dark:text-white tracking-tight">
                  Tạo Kế Hoạch Bài Dạy Song Ngữ Việt – Anh
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200">
                  <Award className="w-3 h-3 mr-1" />
                  GDPT 2018
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Chuyển đổi KHBD tự động giữ nguyên 100% định dạng & độ rộng cột | Tác giả: Đinh Văn Thành (0915.213717)
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {/* Quick Author Contact Badge */}
            <div className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              <PhoneCall className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Thầy Đinh Văn Thành: 0915.213717</span>
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={isDarkMode ? 'Chuyển sang Chế độ sáng' : 'Chuyển sang Chế độ tối (Dark Mode)'}
            >
              {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
            </button>

            {/* CTA button */}
            <button
              onClick={onNewDocClick}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/25 transition-all hover:shadow-lg"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Tạo KHBD mới</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
