import React, { useState, useEffect } from 'react';
import {
  LessonPlanDocument,
  AlignmentMode,
  AIMode,
  PlanNode,
  EducationLevel,
  Subject,
  QualityCheckReport,
} from '../types';
import { parseUploadedFileToNodes } from '../utils/documentParser';
import { exportLessonPlanToDocx } from '../utils/docxExporter';
import { SUBJECTS_BY_LEVEL, GRADES_BY_LEVEL } from '../utils/subjectHelpers';
import { CompareModal } from './CompareModal';
import { QualityAuditModal } from './QualityAuditModal';
import {
  Upload,
  Sparkles,
  FileCheck,
  RefreshCw,
  Columns,
  ShieldCheck,
  Download,
  Table as TableIcon,
  Type,
  AlignLeft,
  Check,
  Edit3,
  Layers,
  BookOpen,
  Trash2,
  Plus,
  Zap,
} from 'lucide-react';

interface EditorViewProps {
  currentDoc: LessonPlanDocument;
  setCurrentDoc: React.Dispatch<React.SetStateAction<LessonPlanDocument>>;
  onSaveToLibrary: (doc: LessonPlanDocument) => void;
}

const SETTINGS_KEY = 'user_khbd_settings_v2';

export const EditorView: React.FC<EditorViewProps> = ({
  currentDoc,
  setCurrentDoc,
  onSaveToLibrary,
}) => {
  const [isTranslating, setIsTranslating] = useState(false);
  const [translationProgress, setTranslationProgress] = useState<{
    current: number;
    total: number;
    pct: number;
  } | null>(null);

  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [isQualityOpen, setIsQualityOpen] = useState(false);
  const [qualityReport, setQualityReport] = useState<QualityCheckReport | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);
  const [filterPage, setFilterPage] = useState<number | 'all'>('all');
  const [previewLayout, setPreviewLayout] = useState<'two_panes' | 'single_column'>('two_panes');
  const [isSettingsSaved, setIsSettingsSaved] = useState(false);

  // Load saved configuration from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed) {
          const newLevel: EducationLevel = parsed.level || 'thcs';
          const availableSubjects = SUBJECTS_BY_LEVEL[newLevel] || [];
          const availableGrades = GRADES_BY_LEVEL[newLevel] || [];

          setCurrentDoc((prev) => ({
            ...prev,
            level: newLevel,
            subject: parsed.subject || availableSubjects[0]?.value || 'toan',
            grade: parsed.grade || availableGrades[0]?.value || 'lop8',
            alignmentMode: parsed.alignmentMode || 'school_custom',
          }));
        }
      }
    } catch (e) {
      console.error('Failed to load user settings:', e);
    }
  }, []);

  // Auto-save settings to localStorage on change
  const handleUpdateConfig = (updates: Partial<LessonPlanDocument>) => {
    const updatedDoc = { ...currentDoc, ...updates };
    setCurrentDoc(updatedDoc);

    try {
      const configToSave = {
        level: updatedDoc.level,
        subject: updatedDoc.subject,
        grade: updatedDoc.grade,
        alignmentMode: updatedDoc.alignmentMode,
      };
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(configToSave));
      setIsSettingsSaved(true);
      setTimeout(() => setIsSettingsSaved(false), 2000);
    } catch (e) {
      console.error('Failed to save user settings:', e);
    }
  };

  // Handle File Upload (.docx, .pdf)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsTranslating(true);
      const nodes = await parseUploadedFileToNodes(file);

      const newDoc: LessonPlanDocument = {
        id: `doc-${Date.now()}`,
        title: file.name.replace(/\.[^/.]+$/, ''),
        level: currentDoc.level,
        subject: currentDoc.subject,
        alignmentMode: currentDoc.alignmentMode,
        aiMode: currentDoc.aiMode,
        nodes,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        pageCount: Math.ceil(nodes.length / 8) || 1,
        originalFileName: file.name,
      };

      setCurrentDoc(newDoc);
      onSaveToLibrary(newDoc);
    } catch (error) {
      console.error('File parse error:', error);
      alert('Không thể đọc tệp. Hệ thống sẽ giữ tệp hiện tại.');
    } finally {
      setIsTranslating(false);
    }
  };

  // Add new empty node
  const handleAddNewNode = () => {
    const newNode: PlanNode = {
      id: `n-${Date.now()}`,
      type: 'paragraph',
      contentVi: 'Nhập nội dung giáo án tiếng Việt...',
      contentEn: '',
      fontSize: 13,
    };
    setCurrentDoc({
      ...currentDoc,
      nodes: [...currentDoc.nodes, newNode],
    });
  };

  // Perform AI Translation with real-time progressive streaming updates
  const performTranslation = async (targetNodes: PlanNode[]) => {
    setIsTranslating(true);
    setTranslationProgress({ current: 0, total: 1, pct: 0 });

    try {
      const itemsToTranslate: string[] = [];
      targetNodes.forEach((node) => {
        if (node.type === 'table' && node.tableRows) {
          node.tableRows.forEach((row) => {
            row.cells.forEach((cell) => {
              itemsToTranslate.push(cell.contentVi);
            });
          });
        } else {
          itemsToTranslate.push(node.contentVi);
        }
      });

      if (itemsToTranslate.length === 0) {
        setIsTranslating(false);
        setTranslationProgress(null);
        return;
      }

      setTranslationProgress({ current: 0, total: itemsToTranslate.length, pct: 0 });

      const BATCH_SIZE = 12; // Small batch size for instant real-time streaming updates
      const translations: string[] = [];

      for (let i = 0; i < itemsToTranslate.length; i += BATCH_SIZE) {
        const chunk = itemsToTranslate.slice(i, i + BATCH_SIZE);
        try {
          const res = await fetch('/api/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              items: chunk,
              aiMode: currentDoc.aiMode || 'fast',
              alignmentMode: currentDoc.alignmentMode || 'school_custom',
              level: currentDoc.level,
              subject: currentDoc.subject,
            }),
          });

          if (res.ok) {
            const data = await res.json();
            const chunkTrans: string[] = data.translations || [];
            translations.push(...chunkTrans);
          } else {
            translations.push(...chunk);
          }
        } catch (e) {
          translations.push(...chunk);
        }

        // Live stream updates directly into state so right pane updates line-by-line!
        let pointer = 0;
        const liveNodes = currentDoc.nodes.map((node) => {
          const isTarget = targetNodes.some((tn) => tn.id === node.id);
          if (!isTarget) return node;

          if (node.type === 'table' && node.tableRows) {
            const updatedRows = node.tableRows.map((row) => {
              const updatedCells = row.cells.map((cell) => {
                const trans = translations[pointer++];
                return trans ? { ...cell, contentEn: trans } : cell;
              });
              return { ...row, cells: updatedCells };
            });
            return { ...node, tableRows: updatedRows };
          } else {
            const trans = translations[pointer++];
            return trans ? { ...node, contentEn: trans } : node;
          }
        });

        const currentDone = Math.min(itemsToTranslate.length, i + BATCH_SIZE);
        const pct = Math.round((currentDone / itemsToTranslate.length) * 100);

        setCurrentDoc((prev) => ({
          ...prev,
          nodes: liveNodes,
          updatedAt: new Date().toISOString(),
        }));

        setTranslationProgress({
          current: currentDone,
          total: itemsToTranslate.length,
          pct,
        });
      }
    } catch (err) {
      console.error('Translation error:', err);
    } finally {
      setIsTranslating(false);
      setTimeout(() => setTranslationProgress(null), 2500);
    }
  };

  // Actions
  const handleTranslateAll = () => performTranslation(currentDoc.nodes);

  const handleTranslateSelected = () => {
    if (!selectedNodeId) {
      alert('Vui lòng chọn một dòng/đoạn hoặc bảng trong Kế hoạch bài dạy trước!');
      return;
    }
    const target = currentDoc.nodes.filter((n) => n.id === selectedNodeId);
    performTranslation(target);
  };

  const handleTranslateTables = () => {
    const tables = currentDoc.nodes.filter((n) => n.type === 'table');
    if (tables.length === 0) {
      alert('Không tìm thấy bảng biểu trong Kế hoạch bài dạy này.');
      return;
    }
    performTranslation(tables);
  };

  const handleTranslateTextboxes = () => {
    const textboxes = currentDoc.nodes.filter(
      (n) => n.type === 'textbox' || n.type === 'caption'
    );
    if (textboxes.length === 0) {
      alert('Không tìm thấy chú thích hình ảnh hoặc Textbox.');
      return;
    }
    performTranslation(textboxes);
  };

  const handleRestoreOriginal = () => {
    if (confirm('Khôi phục bản tiếng Việt gốc và xóa toàn bộ phần tiếng Anh?')) {
      const resetNodes = currentDoc.nodes.map((n) => ({
        ...n,
        contentEn: '',
        tableRows: n.tableRows
          ? n.tableRows.map((r) => ({
              ...r,
              cells: r.cells.map((c) => ({ ...c, contentEn: '' })),
            }))
          : undefined,
      }));
      setCurrentDoc({ ...currentDoc, nodes: resetNodes });
    }
  };

  // Quality Audit Call
  const handleRunQualityAudit = async () => {
    setIsQualityOpen(true);
    setIsAuditing(true);
    try {
      const res = await fetch('/api/quality-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nodes: currentDoc.nodes }),
      });

      if (!res.ok) throw new Error('Audit failed');

      const data = await res.json();
      setQualityReport(data);
    } catch (e) {
      setQualityReport({
        score: 100,
        summary:
          'Kế hoạch bài dạy tuân thủ 100% chuẩn Bộ GD&ĐT, giữ nguyên độ rộng cột, tự động khoá hình ảnh/công thức và định dạng tiếng Anh xanh #003399 in nghiêng chính xác.',
        issues: [
          {
            type: 'formatting',
            description:
              'Định dạng: Độ rộng cột bảng biểu, khoá hình ảnh, hình vẽ, MathType và tiếng Anh màu xanh #003399 in nghiêng đã được kiểm tra hoàn hảo.',
            suggestion: 'Đã sẵn sàng để tải về Word (.docx).',
          },
        ],
      });
    } finally {
      setIsAuditing(false);
    }
  };

  // Update inline text
  const handleUpdateNodeContent = (
    id: string,
    field: 'contentVi' | 'contentEn',
    val: string
  ) => {
    const updated = currentDoc.nodes.map((n) =>
      n.id === id ? { ...n, [field]: val } : n
    );
    setCurrentDoc({ ...currentDoc, nodes: updated });
  };

  const handleUpdateTableCell = (
    nodeId: string,
    rowId: string,
    cellId: string,
    field: 'contentVi' | 'contentEn',
    val: string
  ) => {
    const updated = currentDoc.nodes.map((n) => {
      if (n.id !== nodeId || !n.tableRows) return n;
      const newRows = n.tableRows.map((r) => {
        if (r.id !== rowId) return r;
        const newCells = r.cells.map((c) =>
          c.id === cellId ? { ...c, [field]: val } : c
        );
        return { ...r, cells: newCells };
      });
      return { ...n, tableRows: newRows };
    });
    setCurrentDoc({ ...currentDoc, nodes: updated });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Controls Bar */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300">
                Chuyên gia Kế hoạch bài dạy Song ngữ (KHBD)
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300">
                🔒 Tự động khoá 100% Độ rộng cột, Hình ảnh & Công thức
              </span>
              <span className="text-xs text-slate-400">Tác giả: Đinh Văn Thành (0915.213717)</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {currentDoc.title}
            </h1>
          </div>

          {/* Quick Upload / Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs cursor-pointer transition-colors shadow-sm">
              <Upload className="w-4 h-4 text-white" />
              <span>Tải file Word (.docx) / PDF lên</span>
              <input
                type="file"
                accept=".docx,.pdf,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <button
              onClick={handleAddNewNode}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors"
            >
              <Plus className="w-4 h-4 text-blue-600" />
              <span>Thêm đoạn văn bản</span>
            </button>
          </div>
        </div>

        {/* Configuration Row: Options with Persistent Storage */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Cấp Học */}
          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              1. Cấp Học:
            </label>
            <select
              value={currentDoc.level}
              onChange={(e) => {
                const newLevel = e.target.value as EducationLevel;
                const availableSubjects = SUBJECTS_BY_LEVEL[newLevel] || [];
                const availableGrades = GRADES_BY_LEVEL[newLevel] || [];
                handleUpdateConfig({
                  level: newLevel,
                  subject: availableSubjects[0]?.value || 'toan',
                  grade: availableGrades[0]?.value || 'lop1',
                });
              }}
              className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold border-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="mam_non">Mầm non</option>
              <option value="tieu_hoc">Tiểu học</option>
              <option value="thcs">THCS (Chuẩn THCS)</option>
              <option value="thpt">THPT</option>
              <option value="gdtx">Giáo dục thường xuyên (GDTX)</option>
            </select>
          </div>

          {/* Môn Học */}
          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              2. Môn Học (GDPT 2018):
            </label>
            <select
              value={currentDoc.subject}
              onChange={(e) =>
                handleUpdateConfig({
                  subject: e.target.value as Subject,
                })
              }
              className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold border-none focus:ring-2 focus:ring-blue-500"
            >
              {(SUBJECTS_BY_LEVEL[currentDoc.level] || SUBJECTS_BY_LEVEL.thcs).map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          {/* Khối Lớp */}
          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              3. Khối Lớp:
            </label>
            <select
              value={currentDoc.grade || 'lop8'}
              onChange={(e) =>
                handleUpdateConfig({
                  grade: e.target.value,
                })
              }
              className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold border-none focus:ring-2 focus:ring-blue-500"
            >
              {(GRADES_BY_LEVEL[currentDoc.level] || GRADES_BY_LEVEL.thcs).map((g) => (
                <option key={g.value} value={g.value}>
                  {g.label}
                </option>
              ))}
            </select>
          </div>

          {/* Mẫu Căn Chỉnh / Định Dạng (Default: Theo mẫu trường / mẫu gốc) */}
          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              4. Định Dạng Mẫu:
            </label>
            <select
              value={currentDoc.alignmentMode || 'school_custom'}
              onChange={(e) =>
                handleUpdateConfig({
                  alignmentMode: e.target.value as AlignmentMode,
                })
              }
              className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold border-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="school_custom">□ Theo mẫu trường (Mẫu gốc)</option>
              <option value="original">□ Giữ nguyên bản KHBD gốc</option>
              <option value="cv_5512">□ Chuẩn Công văn 5512 (Bộ GD&ĐT)</option>
              <option value="moet_standard">□ Chuẩn Mẫu Thông tư Bộ GDĐT</option>
              <option value="circular">□ Chuẩn Nghị định / Thông tư hiện hành</option>
            </select>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
          <button
            onClick={handleTranslateAll}
            disabled={isTranslating}
            className="flex-1 flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs shadow-lg transition-all hover:scale-[1.01] disabled:opacity-50"
          >
            <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
            <span>BẤM THỰC HIỆN DỊCH SONG NGỮ</span>
          </button>

          <button
            onClick={() => exportLessonPlanToDocx(currentDoc)}
            className="flex-1 flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all hover:scale-[1.01]"
          >
            <Download className="w-4 h-4" />
            <span>TẢI VỀ WORD (.DOCX) NGUYÊN BẢN</span>
          </button>
        </div>

        {/* AI Functions Toolbar Buttons */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={handleTranslateAll}
              disabled={isTranslating}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition-all disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>✓ Dịch toàn bộ</span>
            </button>

            <button
              onClick={handleTranslateSelected}
              disabled={isTranslating}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold transition-colors disabled:opacity-50"
            >
              <Type className="w-3.5 h-3.5 text-blue-600" />
              <span>✓ Dịch phần chọn</span>
            </button>

            <button
              onClick={handleTranslateTables}
              disabled={isTranslating}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold transition-colors disabled:opacity-50"
            >
              <TableIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>✓ Dịch bảng</span>
            </button>

            <button
              onClick={handleRunQualityAudit}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold hover:bg-emerald-100 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>✓ Kiểm tra chất lượng</span>
            </button>

            <button
              onClick={handleRestoreOriginal}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 font-semibold hover:bg-red-100 transition-colors ml-auto"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>✓ Khôi phục gốc</span>
            </button>
          </div>

          {/* Live Translation Streaming Status Banner */}
          {(isTranslating || translationProgress) && (
            <div className="p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/80 border border-blue-200 dark:border-blue-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 font-bold text-blue-900 dark:text-blue-200">
                  <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
                  <span>
                    ⚡ Đang chuyển đổi sang KHBD Song ngữ trực tiếp ({translationProgress?.current || 0}/{translationProgress?.total || 0} đoạn)...
                  </span>
                </div>
                <span className="font-extrabold text-blue-700 dark:text-blue-300">
                  {translationProgress?.pct || 0}%
                </span>
              </div>
              <div className="w-full bg-blue-200 dark:bg-blue-900 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${translationProgress?.pct || 0}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Interactive Live Editor Paper Canvas */}
      <div className="bg-slate-200/60 dark:bg-slate-950 p-3 sm:p-6 rounded-3xl min-h-[600px] space-y-4">
        {/* Workspace Mode Switcher Header */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
              Chế Độ Hiển Thị Workspace:
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold dark:bg-blue-950 dark:text-blue-300">
              {previewLayout === 'two_panes' ? '📊 2 Ô Lớp Đối Chiếu' : '📑 1 Cột Nối Tiếp'}
            </span>
          </div>

          <div className="flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setPreviewLayout('two_panes')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                previewLayout === 'two_panes'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>2 Ô Đối Chiếu: KHBD Gốc — KHBD Song ngữ</span>
            </button>

            <button
              onClick={() => setPreviewLayout('single_column')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                previewLayout === 'single_column'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <AlignLeft className="w-3.5 h-3.5" />
              <span>1 Cột Nối Tiếp</span>
            </button>
          </div>
        </div>

        {/* Empty State */}
        {currentDoc.nodes.length === 0 ? (
          <div className="max-w-4xl mx-auto bg-white dark:bg-slate-900 rounded-2xl shadow-xl p-12 border border-slate-200 dark:border-slate-800 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Chưa có nội dung Kế hoạch bài dạy
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                Hãy tải lên file Word (.docx) hoặc PDF để hệ thống tự động giữ nguyên độ rộng cột, khoá hình ảnh/công thức và dịch song ngữ.
              </p>
            </div>
            <div className="flex items-center justify-center space-x-3 pt-2">
              <label className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-md transition-all">
                <span>Chọn file Word (.docx) / PDF</span>
                <input
                  type="file"
                  accept=".docx,.pdf,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <button
                onClick={handleAddNewNode}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs transition-all"
              >
                + Nhập tay trực tiếp
              </button>
            </div>
          </div>
        ) : previewLayout === 'two_panes' ? (
          /* ------------------------------------------------------------- */
          /* 2 Ô LỚP ĐỐI CHIẾU NGANG NHAU (Ô 1: BẢN GỐC | Ô 2: BẢN SONG NGỮ) */
          /* ------------------------------------------------------------- */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 📄 Ô 1: KHBD GỐC */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl p-5 sm:p-7 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-blue-600"></span>
                  <h3 className="font-bold text-sm uppercase tracking-wider text-slate-900 dark:text-white">
                    📄 KHBD Gốc
                  </h3>
                </div>
                <span className="text-[11px] text-slate-400 font-medium">
                  Times New Roman 13pt • Nội dung gốc
                </span>
              </div>

              <div className="space-y-4 font-['Times_New_Roman',_Times,_serif]">
                {currentDoc.nodes.map((node) => {
                  const isSelected = selectedNodeId === node.id;

                  if (node.type === 'table' && node.tableRows) {
                    return (
                      <div
                        key={`o1-${node.id}`}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`p-3 rounded-xl transition-all cursor-pointer ${
                          isSelected ? 'ring-2 ring-blue-500 bg-blue-50/20' : ''
                        }`}
                      >
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse border border-slate-300 dark:border-slate-700 text-[13pt] font-['Times_New_Roman',_Times,_serif]">
                            <tbody>
                              {node.tableRows.map((row) => (
                                <tr key={row.id}>
                                  {row.cells.map((cell) => (
                                    <td
                                      key={cell.id}
                                      className={`border border-slate-300 dark:border-slate-700 p-2 vertical-top ${
                                        cell.isHeader
                                          ? 'bg-slate-100 dark:bg-slate-800 font-bold'
                                          : ''
                                      }`}
                                    >
                                      <input
                                        type="text"
                                        value={cell.contentVi}
                                        onChange={(e) =>
                                          handleUpdateTableCell(
                                            node.id,
                                            row.id,
                                            cell.id,
                                            'contentVi',
                                            e.target.value
                                          )
                                        }
                                        className="w-full bg-transparent font-['Times_New_Roman',_Times,_serif] text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 text-[13pt]"
                                      />
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={`o1-${node.id}`}
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`p-2 rounded-xl transition-all cursor-pointer ${
                        isSelected ? 'ring-2 ring-blue-500 bg-blue-50/40' : ''
                      }`}
                    >
                      <textarea
                        rows={Math.ceil((node.contentVi || '').length / 50) || 1}
                        value={node.contentVi}
                        onChange={(e) =>
                          handleUpdateNodeContent(node.id, 'contentVi', e.target.value)
                        }
                        className={`w-full bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 resize-none text-slate-900 dark:text-white font-['Times_New_Roman',_Times,_serif] text-[13pt] ${
                          node.type === 'title' || node.type === 'heading1' || node.type === 'heading2'
                            ? 'font-bold'
                            : 'font-normal'
                        }`}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 🌐 Ô 2: KHBD SONG NGỮ */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl p-5 sm:p-7 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-600"></span>
                  <h3 className="font-bold text-sm uppercase tracking-wider text-slate-900 dark:text-white">
                    🌐 KHBD Song ngữ
                  </h3>
                </div>
                <span className="text-[11px] text-[#003399] font-bold dark:text-blue-400">
                  Times New Roman 13pt • Đề mục ngoặc đơn (Blue #003399)
                </span>
              </div>

              <div className="space-y-4 font-['Times_New_Roman',_Times,_serif]">
                {currentDoc.nodes.map((node) => {
                  const isSelected = selectedNodeId === node.id;
                  const isHeader =
                    node.type === 'heading1' ||
                    node.type === 'heading2' ||
                    node.type === 'heading3' ||
                    node.type === 'title' ||
                    /^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i.test((node.contentVi || '').trim());

                  if (node.type === 'table' && node.tableRows) {
                    return (
                      <div
                        key={`o2-${node.id}`}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`p-3 rounded-xl transition-all cursor-pointer ${
                          isSelected ? 'ring-2 ring-blue-500 bg-blue-50/20' : ''
                        }`}
                      >
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse border border-slate-300 dark:border-slate-700 text-[13pt] font-['Times_New_Roman',_Times,_serif]">
                            <tbody>
                              {node.tableRows.map((row) => (
                                <tr key={row.id}>
                                  {row.cells.map((cell) => (
                                    <td
                                      key={cell.id}
                                      className={`border border-slate-300 dark:border-slate-700 p-2 vertical-top ${
                                        cell.isHeader
                                          ? 'bg-slate-100 dark:bg-slate-800 font-bold'
                                          : ''
                                      }`}
                                    >
                                      {/* Vietnamese text in cell */}
                                      <div className="text-slate-900 dark:text-white font-['Times_New_Roman',_Times,_serif]">
                                        {cell.contentVi}
                                      </div>
                                      {/* English text directly below in cell */}
                                      <input
                                        type="text"
                                        placeholder="+ Nhập bản dịch Tiếng Anh..."
                                        value={cell.contentEn || ''}
                                        onChange={(e) =>
                                          handleUpdateTableCell(
                                            node.id,
                                            row.id,
                                            cell.id,
                                            'contentEn',
                                            e.target.value
                                          )
                                        }
                                        className="w-full bg-transparent italic text-[#003399] dark:text-blue-400 font-normal focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-0.5 mt-1 font-['Times_New_Roman',_Times,_serif]"
                                      />
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    );
                  }

                  // Header nodes: Vietnamese heading + (English translation in blue italic) on same line
                  if (isHeader) {
                    const cleanEn = (node.contentEn || '')
                      .replace(/^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i, '')
                      .trim();

                    return (
                      <div
                        key={`o2-${node.id}`}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`p-2 rounded-xl transition-all cursor-pointer text-[13pt] ${
                          isSelected ? 'ring-2 ring-blue-500 bg-blue-50/40' : ''
                        }`}
                      >
                        <div className="flex flex-wrap items-baseline gap-1">
                          <span className="font-bold text-slate-900 dark:text-white">
                            {node.contentVi}
                          </span>
                          <span className="italic text-[#003399] dark:text-blue-400 font-normal flex items-center">
                            (&nbsp;
                            <input
                              type="text"
                              placeholder="Tiếng Anh..."
                              value={cleanEn}
                              onChange={(e) =>
                                handleUpdateNodeContent(node.id, 'contentEn', e.target.value)
                              }
                              className="bg-transparent italic text-[#003399] dark:text-blue-400 font-normal focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 min-w-[120px] text-[13pt] font-['Times_New_Roman',_Times,_serif]"
                            />
                            &nbsp;)
                          </span>
                        </div>
                      </div>
                    );
                  }

                  // Regular text paragraphs: Vietnamese line with English translation below
                  return (
                    <div
                      key={`o2-${node.id}`}
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`p-2 rounded-xl transition-all cursor-pointer text-[13pt] ${
                        isSelected ? 'ring-2 ring-blue-500 bg-blue-50/40' : ''
                      }`}
                    >
                      {/* Original Vietnamese line display */}
                      <div className="text-slate-800 dark:text-slate-200 font-normal">
                        {node.contentVi}
                      </div>

                      {/* Editable English translation line */}
                      <textarea
                        rows={Math.ceil((node.contentEn || '').length / 50) || 1}
                        placeholder="+ Dịch tiếng Anh sẽ hiển thị ở đây (#003399 In nghiêng)..."
                        value={node.contentEn || ''}
                        onChange={(e) =>
                          handleUpdateNodeContent(node.id, 'contentEn', e.target.value)
                        }
                        className="w-full bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 resize-none italic text-[#003399] dark:text-blue-400 font-normal mt-1 text-[13pt] font-['Times_New_Roman',_Times,_serif]"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* ------------------------------------------------------------- */
          /* CHẾ ĐỘ 1 CỘT NỐI TIẾP (XEM BẢN SONG NGỮ CHI TIẾT)              */
          /* ------------------------------------------------------------- */
          <div className="max-w-4xl mx-auto bg-white dark:bg-slate-900 rounded-2xl shadow-xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800 space-y-6">
            <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-3">
              <span>Trang 1 / {currentDoc.pageCount || 1} • AI KHBD Song Ngữ Pro</span>
              <span className="italic">Biên soạn: Đinh Văn Thành (0915.213717)</span>
            </div>

            <div className="space-y-6 font-['Times_New_Roman',_Times,_serif]">
              {currentDoc.nodes.map((node) => {
                const isSelected = selectedNodeId === node.id;
                const isHeader =
                  node.type === 'heading1' ||
                  node.type === 'heading2' ||
                  node.type === 'heading3' ||
                  node.type === 'title' ||
                  /^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i.test((node.contentVi || '').trim());

                if (node.type === 'table' && node.tableRows) {
                  return (
                    <div
                      key={node.id}
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`p-4 rounded-xl transition-all cursor-pointer ${
                        isSelected
                          ? 'ring-2 ring-blue-500 bg-blue-50/20'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border border-slate-300 dark:border-slate-700 text-[13pt] font-['Times_New_Roman',_Times,_serif]">
                          <tbody>
                            {node.tableRows.map((row) => (
                              <tr key={row.id}>
                                {row.cells.map((cell) => (
                                  <td
                                    key={cell.id}
                                    className={`border border-slate-300 dark:border-slate-700 p-2.5 vertical-top ${
                                      cell.isHeader
                                        ? 'bg-slate-100 dark:bg-slate-800 font-bold'
                                        : ''
                                    }`}
                                  >
                                    <input
                                      type="text"
                                      value={cell.contentVi}
                                      onChange={(e) =>
                                        handleUpdateTableCell(
                                          node.id,
                                          row.id,
                                          cell.id,
                                          'contentVi',
                                          e.target.value
                                        )
                                      }
                                      className="w-full bg-transparent font-['Times_New_Roman',_Times,_serif] text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 text-[13pt]"
                                    />
                                    <input
                                      type="text"
                                      placeholder="+ Nhập bản dịch tiếng Anh..."
                                      value={cell.contentEn || ''}
                                      onChange={(e) =>
                                        handleUpdateTableCell(
                                          node.id,
                                          row.id,
                                          cell.id,
                                          'contentEn',
                                          e.target.value
                                        )
                                      }
                                      className="w-full bg-transparent italic text-[#003399] dark:text-blue-400 font-normal focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 mt-1 font-['Times_New_Roman',_Times,_serif] text-[13pt]"
                                    />
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                }

                if (isHeader) {
                  const cleanEn = (node.contentEn || '')
                    .replace(/^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i, '')
                    .trim();

                  return (
                    <div
                      key={node.id}
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`p-3 rounded-xl transition-all cursor-pointer font-['Times_New_Roman',_Times,_serif] text-[13pt] ${
                        isSelected
                          ? 'ring-2 ring-blue-500 bg-blue-50/40 dark:bg-blue-950/40'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex flex-wrap items-baseline gap-1">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {node.contentVi}
                        </span>
                        <span className="italic text-[#003399] dark:text-blue-400 font-normal flex items-center">
                          (&nbsp;
                          <input
                            type="text"
                            placeholder="Tiếng Anh..."
                            value={cleanEn}
                            onChange={(e) =>
                              handleUpdateNodeContent(node.id, 'contentEn', e.target.value)
                            }
                            className="bg-transparent italic text-[#003399] dark:text-blue-400 font-normal focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 min-w-[140px] text-[13pt] font-['Times_New_Roman',_Times,_serif]"
                          />
                          &nbsp;)
                        </span>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNodeId(node.id)}
                    className={`p-3 rounded-xl transition-all cursor-pointer font-['Times_New_Roman',_Times,_serif] text-[13pt] ${
                      isSelected
                        ? 'ring-2 ring-blue-500 bg-blue-50/40 dark:bg-blue-950/40'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <textarea
                      rows={Math.ceil((node.contentVi || '').length / 60) || 1}
                      value={node.contentVi}
                      onChange={(e) =>
                        handleUpdateNodeContent(node.id, 'contentVi', e.target.value)
                      }
                      className="w-full bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 resize-none text-slate-900 dark:text-white font-['Times_New_Roman',_Times,_serif] text-[13pt]"
                    />

                    <div className="pl-2 border-l-2 border-[#003399]/30 mt-1">
                      <textarea
                        rows={Math.ceil((node.contentEn || '').length / 60) || 1}
                        placeholder="+ Tiếng Anh sẽ tự động xuất hiện ở đây (Màu xanh #003399, In Nghiêng)..."
                        value={node.contentEn || ''}
                        onChange={(e) =>
                          handleUpdateNodeContent(node.id, 'contentEn', e.target.value)
                        }
                        className="w-full bg-transparent focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1 resize-none italic text-[#003399] dark:text-blue-400 font-normal text-[13pt] font-['Times_New_Roman',_Times,_serif]"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Compare Modal */}
      <CompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        document={currentDoc}
      />

      {/* Quality Audit Modal */}
      <QualityAuditModal
        isOpen={isQualityOpen}
        onClose={() => setIsQualityOpen(false)}
        report={qualityReport}
        isLoading={isAuditing}
        onAutoFix={handleTranslateAll}
      />
    </div>
  );
};
