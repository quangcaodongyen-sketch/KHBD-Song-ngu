import React from 'react';
import { Phone, Mail, Award, ShieldCheck, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 py-8 px-4 sm:px-6 lg:px-8 mt-auto">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center space-x-2 font-bold text-white text-base mb-2">
            <Award className="w-5 h-5 text-blue-400" />
            <span>AI LessonPlan Bilingual Pro</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Hệ thống chuyển đổi Kế hoạch bài dạy (KHBD) tiếng Việt sang song ngữ Việt - Anh thông minh, giữ nguyên 100% bố cục, độ rộng cột, khoá hình ảnh, hình vẽ, công thức toán và chuẩn mực Công văn 5512/BGDĐT.
          </p>
        </div>

        <div>
          <h4 className="font-semibold text-white text-xs uppercase tracking-wider mb-2">
            Thông tin Tác giả & Hỗ trợ
          </h4>
          <ul className="space-y-1.5 text-xs text-slate-400">
            <li className="flex items-center space-x-2">
              <span className="font-medium text-slate-200">Tác giả:</span>
              <span>Đinh Văn Thành</span>
            </li>
            <li className="flex items-center space-x-2">
              <Phone className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-medium text-slate-200">Điện thoại / Zalo:</span>
              <a href="tel:0915213717" className="text-blue-400 hover:underline">
                0915.213717
              </a>
            </li>
            <li className="flex items-center space-x-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Cập nhật liên tục theo chuẩn GDPT 2018 & Bộ GD&ĐT</span>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-white text-xs uppercase tracking-wider mb-2">
            Cam kết Bảo mật & Chất lượng
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            An toàn dữ liệu tuyệt đối. Không lưu trữ tài liệu nếu người dùng không yêu cầu. Dịch thuật theo thuật ngữ học thuật Bộ GD&ĐT, Cambridge & CEFR.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-8 pt-4 border-t border-slate-800 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between">
        <p>© 2026 AI LessonPlan Bilingual Pro. Phát triển bởi Đinh Văn Thành (0915.213717).</p>
        <p className="flex items-center mt-2 sm:mt-0">
          <span>Dành riêng cho Giáo viên Việt Nam</span>
          <Heart className="w-3.5 h-3.5 text-red-500 ml-1 inline" />
        </p>
      </div>
    </footer>
  );
};
