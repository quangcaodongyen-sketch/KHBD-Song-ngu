import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
  Header,
  Footer,
  PageNumber,
  HeadingLevel,
} from 'docx';
import { saveAs } from 'file-saver';
import { LessonPlanDocument, PlanNode } from '../types';

export const BLUE_COLOR = '003399'; // RGB(0, 51, 153)

export async function exportLessonPlanToDocx(doc: LessonPlanDocument) {
  const childrenElements: any[] = [];

  // Document Title Header Banner
  childrenElements.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200, before: 100 },
      children: [
        new TextRun({
          text: doc.title,
          bold: true,
          size: 32, // 16pt
          font: 'Times New Roman',
          color: '000000',
        }),
      ],
    })
  );

  for (const node of doc.nodes) {
    if (node.type === 'table' && node.tableRows && node.tableRows.length > 0) {
      // Create Docx Table
      const docxRows = node.tableRows.map((row) => {
        const docxCells = row.cells.map((cell) => {
          const cellParagraphs: Paragraph[] = [];

          // Vietnamese Cell Text
          cellParagraphs.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: cell.contentVi,
                  bold: cell.isHeader || false,
                  size: 24, // 12pt
                  font: 'Times New Roman',
                  color: '000000',
                }),
              ],
            })
          );

          // English Cell Text (Underneath, Deep Blue #003399, Italic, Not Bold)
          if (cell.contentEn) {
            cellParagraphs.push(
              new Paragraph({
                spacing: { before: 40 },
                children: [
                  new TextRun({
                    text: cell.contentEn,
                    italics: true,
                    bold: false,
                    size: 24, // 12pt
                    font: 'Times New Roman',
                    color: BLUE_COLOR,
                  }),
                ],
              })
            );
          }

          return new TableCell({
            children: cellParagraphs,
            width: { size: 100 / row.cells.length, type: WidthType.PERCENTAGE },
            shading: cell.isHeader ? { fill: 'F0F4FA' } : undefined,
            borders: {
              top: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC' },
              bottom: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC' },
              left: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC' },
              right: { style: BorderStyle.SINGLE, size: 4, color: 'CCCCCC' },
            },
          });
        });

        return new TableRow({
          children: docxCells,
        });
      });

      const table = new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: docxRows,
      });

      childrenElements.push(table);
      childrenElements.push(new Paragraph({ spacing: { after: 120 } }));
      continue;
    }

    // Standard Paragraph / Heading / Title / Bullet / Textbox
    let align: any = AlignmentType.LEFT;
    if (node.align === 'center') align = AlignmentType.CENTER;
    if (node.align === 'right') align = AlignmentType.RIGHT;
    if (node.align === 'justify') align = AlignmentType.JUSTIFIED;

    const fontSizePts = (node.fontSize || 13) * 2; // docx size is in half-points (13pt = 26)

    const isHeaderNode =
      node.type === 'heading1' ||
      node.type === 'heading2' ||
      node.type === 'heading3' ||
      node.type === 'title' ||
      /^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i.test(node.contentVi.trim());

    if (isHeaderNode) {
      // Clean leading index numbers from English translation if present
      const cleanEn = (node.contentEn || '')
        .replace(/^(I|II|III|IV|V|VI|VII|VIII|IX|X|\d+|[A-Z])[\.\:]\s*/i, '')
        .trim();

      const textRuns: TextRun[] = [
        new TextRun({
          text: (node.type === 'bullet' ? '• ' : '') + node.contentVi,
          bold: node.isBold ?? true,
          italics: node.isItalic || false,
          size: fontSizePts,
          font: 'Times New Roman',
          color: '000000',
        }),
      ];

      // Append English translation in parenthetical blue italic right after heading title
      if (cleanEn) {
        textRuns.push(
          new TextRun({
            text: ` (${cleanEn})`,
            italics: true,
            bold: false,
            size: fontSizePts,
            font: 'Times New Roman',
            color: BLUE_COLOR,
          })
        );
      }

      childrenElements.push(
        new Paragraph({
          alignment: align,
          spacing: { before: isHeaderNode ? 160 : 60, after: 80 },
          children: textRuns,
        })
      );
    } else {
      // 1. Vietnamese Line for regular text/bullet/paragraph
      const viTextRun = new TextRun({
        text: (node.type === 'bullet' ? '• ' : '') + node.contentVi,
        bold: node.isBold || false,
        italics: node.isItalic || false,
        size: fontSizePts,
        font: 'Times New Roman',
        color: '000000',
      });

      childrenElements.push(
        new Paragraph({
          alignment: align,
          spacing: { before: 60, after: 20 },
          children: [viTextRun],
        })
      );

      // 2. English Line Below (Deep Blue #003399, Italic, Not Bold, 13pt Times New Roman)
      if (node.contentEn) {
        const enTextRun = new TextRun({
          text: (node.type === 'bullet' ? '  ' : '') + node.contentEn,
          italics: true, // MUST be italic
          bold: false, // MUST NOT be bold
          size: fontSizePts, // 13pt
          font: 'Times New Roman',
          color: BLUE_COLOR, // Deep Blue RGB(0, 51, 153)
        });

        childrenElements.push(
          new Paragraph({
            alignment: align,
            spacing: { before: 20, after: 100 },
            children: [enTextRun],
          })
        );
      }
    }
  }

  // Create Docx Document
  const docxFile = new Document({
    sections: [
      {
        properties: {},
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({
                    text: 'AI Kế Hoạch Bài Dạy Song Ngữ (KHBD) - Chuẩn Bộ GD&ĐT',
                    size: 18,
                    italics: true,
                    color: '888888',
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: 'AI Kế Hoạch Bài Dạy Song Ngữ Pro (KHBD) | Biên soạn: Đinh Văn Thành (0915.213717)', italics: true, size: 18 }),
                ],
              }),
            ],
          }),
        },
        children: childrenElements,
      },
    ],
  });

  // Pack and Save
  const blob = await Packer.toBlob(docxFile);
  const cleanTitle = doc.title.replace(/[^a-zA-Z0-9_ -]/g, '_');
  saveAs(blob, `${cleanTitle}_SongNgu_BoGDDT.docx`);
}
